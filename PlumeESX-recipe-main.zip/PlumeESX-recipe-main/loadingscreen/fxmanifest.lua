fx_version 'cerulean'
games { 'rdr3', 'gta5' }

author 'PlumeESX'
description 'Example loading screen originally based on Loqrin\'s page design.'
version '1.0.0'

files {
    'index.html',
    'background.css',
    'config.js',
}

loadscreen 'index.html'
